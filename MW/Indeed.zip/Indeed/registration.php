<?php
/**
 *  Mage-World
 *
 * @category    Mage-World
 * @package     MW
 * @author      Dreyar Developer (dreyar@mage-world.com)
 *
 * @copyright   Copyright (c) 2018 Mage-World (https://www.mage-world.com/)
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'MW_Indeed',
    __DIR__
);
